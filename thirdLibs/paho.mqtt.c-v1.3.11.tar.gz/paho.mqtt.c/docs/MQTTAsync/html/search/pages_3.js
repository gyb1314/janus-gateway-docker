var searchData=
[
  ['quality_20of_20service_702',['Quality of service',['../qos.html',1,'']]]
];
