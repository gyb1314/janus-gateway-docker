# lws api test lws_dsh

Demonstrates how to use and performs selftests for lws_dsh

## build

```
 $ cmake . && make
```

## usage

Commandline option|Meaning
---|---
-d <loglevel>|Debug verbosity in decimal, eg, -d15

```
 $ ./lws-api-test-lws_dsh
[2018/10/09 09:14:17:4834] USER: LWS API selftest: lws_dsh
[2018/10/09 09:14:17:4835] USER: Completed: PASS
```

