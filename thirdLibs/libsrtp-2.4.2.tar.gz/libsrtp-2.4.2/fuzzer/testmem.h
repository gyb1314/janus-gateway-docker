#include <stdint.h>
#include <stddef.h>
void fuzz_testmem(void *data, size_t size);
